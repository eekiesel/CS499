package com.example.weighttracking;


import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import android.Manifest;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.content.Intent;
import android.widget.EditText;
import android.widget.Toast;
import androidx.recyclerview.widget.RecyclerView;
import java.util.ArrayList;
import java.util.List;
import android.widget.TextView;

public class HomeActivity extends AppCompatActivity {

    private RecyclerView weightHistoryRecyclerView;
    @SuppressWarnings("FieldCanBeLocal")
    private Button dailyEntryButton, goalEntryButton, logoutButton;
    private TextView goalWeightTextView;
    private DatabaseHelper dbHelper;

    private int getCurrentUserId() {
        SharedPreferences sharedPreferences = getSharedPreferences("AppPrefs", MODE_PRIVATE);
        return sharedPreferences.getInt("current_user_id", -1); // Default to -1 if not found
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

        checkSmsPermission();

        // initialize UI Components
        weightHistoryRecyclerView = findViewById(R.id.weightHistoryRecyclerView);
        dailyEntryButton = findViewById(R.id.dailyEntryButton);
        goalEntryButton = findViewById(R.id.goalEntryButton);
        logoutButton = findViewById(R.id.logoutButton);
        goalWeightTextView = findViewById(R.id.goalWeightTextView);

        // initialize DatabaseHelper
        dbHelper = new DatabaseHelper(this);

        // retrieve and display goal weight
        loadGoalWeight();

        // set up RecyclerView
        weightHistoryRecyclerView.setLayoutManager(new LinearLayoutManager(this));
        refreshWeightHistory();

        // button listeners
        dailyEntryButton.setOnClickListener(v -> {
            Toast.makeText(HomeActivity.this, "Navigating to Daily Entry", Toast.LENGTH_SHORT).show();
            Intent intent = new Intent(HomeActivity.this, DailyEntryActivity.class);
            startActivity(intent);
        });

        goalEntryButton.setOnClickListener(v -> {
            Toast.makeText(HomeActivity.this, "Navigating to Set Goal", Toast.LENGTH_SHORT).show();
            Intent intent = new Intent(HomeActivity.this, GoalEntryActivity.class);
            startActivity(intent);
        });

        logoutButton.setOnClickListener(v -> {
            Toast.makeText(HomeActivity.this, "Logging out", Toast.LENGTH_SHORT).show();
            Intent intent = new Intent(HomeActivity.this, MainActivity.class);
            startActivity(intent);
            finish();
        });

    }

    @Override
    protected void onResume() {
        super.onResume();
        loadGoalWeight();
        refreshWeightHistory();

        // Get the latest weight and check goal
        int currentUserId = getCurrentUserId();
        Cursor cursor = dbHelper.getLatestWeightEntry(currentUserId);
        if (cursor != null && cursor.moveToFirst()) {
            int weightIndex = cursor.getColumnIndex(DatabaseHelper.COLUMN_WEIGHT);
            if (weightIndex != -1) {
                double latestWeight = cursor.getDouble(weightIndex);
                checkGoalWeight(latestWeight);
            }
            cursor.close();
        } else {
            Log.e("HomeActivity", "No weight entries found for current user.");
        }
    }

    private void loadGoalWeight() {
        int currentUserId = getCurrentUserId(); // Get logged-in user ID
        try (Cursor goalCursor = dbHelper.getGoalWeight(currentUserId)) { // Try-with-resources
            if (goalCursor != null && goalCursor.moveToLast()) {
                int goalWeightIndex = goalCursor.getColumnIndex(DatabaseHelper.COLUMN_GOAL_WEIGHT);
                if (goalWeightIndex != -1) {
                    double goalWeight = goalCursor.getDouble(goalWeightIndex);
                    goalWeightTextView.setText(getString(R.string.goal_weight_text, goalWeight));
                } else {
                    goalWeightTextView.setText(R.string.set_goal_weight);
                }
            } else {
                goalWeightTextView.setText(R.string.set_goal_weight);
            }
        } catch (Exception e) {
            Log.e("HomeActivity", "Failed to load goal weight", e);
        }
    }

    private List<WeightEntry> getWeightEntriesFromDatabase() {
        List<WeightEntry> data = new ArrayList<>();
        int currentUserId = getCurrentUserId(); // Retrieve logged-in user's ID
        Cursor cursor = dbHelper.getAllWeightEntries(currentUserId);
        if (cursor != null) {
            int idIndex = cursor.getColumnIndex(DatabaseHelper.COLUMN_WEIGHT_ID);
            int dateIndex = cursor.getColumnIndex(DatabaseHelper.COLUMN_DATE);
            int weightIndex = cursor.getColumnIndex(DatabaseHelper.COLUMN_WEIGHT);

            if (idIndex == -1 || dateIndex == -1 || weightIndex == -1) {
                Log.e("HomeActivity", "Error: One or more column indices are invalid.");
                cursor.close();
                return data;
            }

            while (cursor.moveToNext()) {
                int id = cursor.getInt(idIndex);
                String date = cursor.getString(dateIndex);
                double weight = cursor.getDouble(weightIndex);
                data.add(new WeightEntry(id, date, weight));
            }
            cursor.close();
        }
        return data;
    }

    private void refreshWeightHistory() {
        List<WeightEntry> weightEntries = getWeightEntriesFromDatabase();
        WeightHistoryAdapter adapter = new WeightHistoryAdapter(weightEntries,
                this::openEditDialog,
                this::confirmAndDeleteEntry
        );
        weightHistoryRecyclerView.setAdapter(adapter);
    }

    private void openEditDialog(int entryId, String oldDate, String oldWeight) {
        // create dialog for editing
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Edit Entry");

        // inflate custom dialog layout
        View dialogView = getLayoutInflater().inflate(R.layout.dialog_edit_entry, null);
        EditText dateInput = dialogView.findViewById(R.id.editDateInput);
        EditText weightInput = dialogView.findViewById(R.id.editWeightInput);

        // set existing values
        dateInput.setText(oldDate);
        weightInput.setText(oldWeight);

        builder.setView(dialogView);

        // save changes
        builder.setPositiveButton("Save", (dialog, which) -> {
            String newDate = dateInput.getText().toString().trim();
            String newWeightStr = weightInput.getText().toString().trim();

            if (!newDate.isEmpty() && !newWeightStr.isEmpty()) {
                try {
                    double newWeight = Double.parseDouble(newWeightStr);
                    int rowsUpdated = dbHelper.updateWeightEntry(entryId, newDate, newWeight);
                    if (rowsUpdated > 0) {
                        Toast.makeText(HomeActivity.this, "Entry updated successfully", Toast.LENGTH_SHORT).show();
                        refreshWeightHistory();
                    } else {
                        Toast.makeText(HomeActivity.this, "Failed to update entry", Toast.LENGTH_SHORT).show();
                    }
                } catch (NumberFormatException e) {
                    Toast.makeText(HomeActivity.this, "Invalid weight format", Toast.LENGTH_SHORT).show();
                }
            } else {
                Toast.makeText(HomeActivity.this, "Fields cannot be empty", Toast.LENGTH_SHORT).show();
            }
        });

        // cancel
        builder.setNegativeButton("Cancel", (dialog, which) -> dialog.dismiss());

        builder.create().show();
    }

    private void confirmAndDeleteEntry(int entryId) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Delete Entry");
        builder.setMessage("Are you sure you want to delete this entry?");

        builder.setPositiveButton("Yes", (dialog, which) -> {
            int rowsDeleted = dbHelper.deleteWeightEntry(entryId);
            if (rowsDeleted > 0) {
                Toast.makeText(HomeActivity.this, "Entry deleted successfully", Toast.LENGTH_SHORT).show();
                refreshWeightHistory();
            } else {
                Toast.makeText(HomeActivity.this, "Failed to delete entry", Toast.LENGTH_SHORT).show();
            }
        });

        builder.setNegativeButton("No", (dialog, which) -> dialog.dismiss());

        builder.create().show();
    }

    private void sendGoalAchievedNotification(double currentWeight, double goalWeight) {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS) == PackageManager.PERMISSION_GRANTED) {
            try {
                SmsManager smsManager = SmsManager.getDefault();
                String phoneNumber = "+15551234567"; // emulator's phone number
                String message = "Congratulations! You've achieved your goal weight of " + goalWeight + " lbs. Current weight: " + currentWeight + " lbs.";
                smsManager.sendTextMessage(phoneNumber, null, message, null, null);
                Toast.makeText(this, "Goal weight achieved notification sent via SMS", Toast.LENGTH_SHORT).show();
            } catch (Exception e) {
                Log.e("HomeActivity", "Error loading goal weight", e);
            }
        } else {
            // Notify user without SMS
            Toast.makeText(this, "Goal achieved! SMS notifications are disabled.", Toast.LENGTH_SHORT).show();
        }
    }

    // check if user has met goal weight
    private void checkGoalWeight(double currentWeight) {
        int currentUserId = getCurrentUserId(); // Retrieve logged-in user's ID
        Cursor goalCursor = dbHelper.getGoalWeight(currentUserId); // Pass user ID
        if (goalCursor != null && goalCursor.moveToLast()) {
            int goalWeightIndex = goalCursor.getColumnIndex(DatabaseHelper.COLUMN_GOAL_WEIGHT);
            if (goalWeightIndex != -1) {
                double goalWeight = goalCursor.getDouble(goalWeightIndex);
                if (currentWeight <= goalWeight) {
                    sendGoalAchievedNotification(currentWeight, goalWeight);
                }
            } else {
                Log.e("HomeActivity", "COLUMN_GOAL_WEIGHT not found in cursor.");
            }
            goalCursor.close();
        } else {
            Log.e("HomeActivity", "Goal weight cursor is null or empty.");
        }
    }


    private void checkSmsPermission() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.SEND_SMS}, 100);
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == 100) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                Toast.makeText(this, "SMS Permission Granted", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(this, "SMS Permission Denied. Notifications will not be sent via SMS.", Toast.LENGTH_SHORT).show();
            }
        }
    }

}