package com.example.weighttracking;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import android.Manifest;
import android.content.pm.PackageManager;
import android.telephony.SmsManager;
import androidx.annotation.NonNull;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import android.text.TextUtils;

public class GoalEntryActivity extends AppCompatActivity {

    private EditText goalWeightInput;
    @SuppressWarnings("FieldCanBeLocal")
    private Button saveButton, cancelButton, requestSmsPermissionButton;
    private static final int SMS_PERMISSION_CODE = 100;
    private DatabaseHelper dbHelper;


    private int getCurrentUserId() {
        SharedPreferences sharedPreferences = getSharedPreferences("AppPrefs", MODE_PRIVATE);
        return sharedPreferences.getInt("current_user_id", -1); // Default to -1 if not found
    }


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_goal_entry);

        // initialize UI components
        goalWeightInput = findViewById(R.id.goalWeightInput);
        saveButton = findViewById(R.id.saveButton);
        cancelButton = findViewById(R.id.cancelButton);
        requestSmsPermissionButton = findViewById(R.id.requestSmsPermissionButton);

        // initialize Database Helper
        dbHelper = new DatabaseHelper(this);

        // save button listener
        saveButton.setOnClickListener(v -> {
            String goalWeight = goalWeightInput.getText().toString().trim();
            if (TextUtils.isEmpty(goalWeight)) {
                Toast.makeText(GoalEntryActivity.this, "Enter goal weight", Toast.LENGTH_SHORT).show();
            } else {
                try {
                    double goalWeightValue = Double.parseDouble(goalWeight);
                    int currentUserId = getCurrentUserId(); // Get the current user ID

                    // save the goal weight for the logged-in user
                    long result = dbHelper.setGoalWeight(goalWeightValue, currentUserId);
                    if (result != -1) {
                        Toast.makeText(GoalEntryActivity.this, "Goal weight saved successfully!", Toast.LENGTH_SHORT).show();
                        setResult(RESULT_OK); // Set result for HomeActivity
                        finish();
                    } else {
                        Toast.makeText(GoalEntryActivity.this, "Failed to save goal weight. Try again.", Toast.LENGTH_SHORT).show();
                    }
                } catch (NumberFormatException e) {
                    Toast.makeText(GoalEntryActivity.this, "Enter a valid weight", Toast.LENGTH_SHORT).show();
                }
            }
        });

        // cancel button listener
        cancelButton.setOnClickListener(v -> finish());

        // SMS permission button listener
        requestSmsPermissionButton.setOnClickListener(v -> checkAndRequestSmsPermission());


    }

    // check and request SMS permission
    private void checkAndRequestSmsPermission() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS)
            != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this,
                    new String[]{Manifest.permission.SEND_SMS}, SMS_PERMISSION_CODE);
        } else {
            sendSmsNotification();
        }
    }

    // send SMS notification
    private void sendSmsNotification() {
        try {
            SmsManager smsManager = SmsManager.getDefault();
            String phoneNumber = "+15551234567"; // emulator phone number
            String message = "You've enabled SMS notifications";
            smsManager.sendTextMessage(phoneNumber, null, message, null, null);
            Toast.makeText(this, "SMS Sent Successfully", Toast.LENGTH_SHORT).show();
        } catch (Exception e) {
            Toast.makeText(this, "Failed to send SMS", Toast.LENGTH_SHORT).show();
            Log.e("GoalEntryActivity", "Failed to send SMS", e);
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == SMS_PERMISSION_CODE) {
            if (grantResults.length >0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                sendSmsNotification();
            } else {
                Toast.makeText(this, "SMS Permission Denied. Notifications will not be sent via SMS.", Toast.LENGTH_SHORT).show();
            }
        }
    }


}